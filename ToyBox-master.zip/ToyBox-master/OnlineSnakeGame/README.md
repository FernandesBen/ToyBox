# OnlineSnakeGame

Creates a live online multiplayer snake game using websockets.

## How to Use
Start the server by typing the command "node server.js". Connect to the server by opening a browser and connecting to the computer's IP address on port 3000. Ex. 192.168.40.179:3000.
