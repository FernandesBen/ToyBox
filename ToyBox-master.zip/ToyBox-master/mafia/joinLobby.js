const username = document.getElementById('usernameInput').innerHTML;
const socket = io();
