README

Capstone CSC 599 submission. 
By Ryan King, Ben Fernandes, and Dan Baartman. 

Downloads required to run our software:
node.js
socket.io
hostapd on Raspberry Pi 4

The following folders will need a node_modules folder: chat, mafia, snake, and ToyBox. 
The node_modules folder can be found by opening command prompt, navigating to these folders, 
and entering 'npm install'. 

Everything inside the 'chat' folder was not made by us, but was retreived from 
https://github.com/bradtraversy/chatcord

Everything else was made by us. 