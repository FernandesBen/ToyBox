//server logic
const socket = io.connect();
var clientSnake;

//drawing gameboard
const gameboard = document.getElementById("board");
const ctx = gameboard.getContext("2d");
const rows = 18;
const columns = 32;
const yOffset = 0;
const pixel = (window.innerHeight - yOffset)/rows;
const wid = pixel * columns;
const hei = pixel * rows;
gameboard.width = wid;
gameboard.height = hei;
gameboard.style.backgroundColor = "green";
gameboard.style.border = "10px solid black";

function drawBackground() {
    ctx.fillStyle = "#E0FFFF";
    ctx.fillRect(0,0,wid,hei);
}
drawBackground();

function drawRect(location, color) {
    console.log("              "+location)
    var y = Math.floor(location%10000)*pixel;
    var x = Math.round(location/10000)*pixel;

/*
    var img1 = new Image();
    img1.onload = start;
    img1.src="head-down.png";
    function start() {
      pattern1 = ctx.createPattern(img1, 'repeat');
      ctx.fillStyle = pattern1;
      ctx.fillRect(x, y, pixel, pixel);
    }
*/

    ctx.fillStyle=color;
    ctx.fillRect(x, y, pixel, pixel);
}

function drawFruit(fruit) {
    ctx.fillStyle="#ff0400";
    ctx.fillRect(fruit.x,fruit.y,pixel,pixel);
}

//client only sends direction to server
socket.on("update", function(data) {
    var snakes = data["snakes"];
    var apples = data["apples"];
    drawBackground();
    for(i=0; i<apples.length; i++) {
        drawRect(apples[i], "red");
    }
    for(var key in snakes) {
        var body = snakes[key]["body"]
        for(j=0; j<body.length; j++) {
            drawRect(body[j],"#bfee3f");
        }
        if(key === socket.id){
            clientSnake = snakes[key];
        }

    }
    document.getElementById("score").innerHTML=clientSnake["score"];
});

socket.on("the end", function(finalScore) {
    console.log("you died");
    //document.defaultView.alert("You died :( \n Score: " + finalScore);
    //board.remove();
})
