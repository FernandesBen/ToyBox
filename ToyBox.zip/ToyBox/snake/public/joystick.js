var canvas, jctx;
var aim;
var left = -10000;
var right = 10000;
var up = -1;
var down = 1;

window.addEventListener('load', () => {

    canvas = document.getElementById('joycon');
    jctx = canvas.getContext('2d');
    resize();

    document.addEventListener('keydown', arrowkeys);
    document.addEventListener('mousedown', startDrawing);
    document.addEventListener('mouseup', stopDrawing);
    document.addEventListener('mousemove', Draw);

    document.addEventListener('touchstart', startDrawing);
    document.addEventListener('touchend', stopDrawing);
    document.addEventListener('touchcancel', stopDrawing);
    document.addEventListener('touchmove', Draw);
    window.addEventListener('resize', resize);

/*
    document.getElementById("x_coordinate").innerText = 0;
    document.getElementById("y_coordinate").innerText = 0;
    document.getElementById("speed").innerText = 0;
    document.getElementById("angle").innerText = 0;
    document.getElementById("dd").innerText = 0;
*/
});




var width, height, radius, x_orig, y_orig;
function resize() {
    //width = window.innerWidth;
    width = 125;
    radius = 15;
    height = radius * 6.5;
    jctx.canvas.width = width;
    jctx.canvas.height = height;
    background();
    joystick(width / 2, height / 3);
}

function background() {
    x_orig = width / 2;
    y_orig = height / 3;

    jctx.beginPath();
    jctx.arc(x_orig, y_orig, radius + 15, 0, Math.PI * 2, true);
    jctx.fillStyle = '#ECE5E5';
    jctx.fill();
}

function joystick(width, height) {
    jctx.beginPath();
    jctx.arc(width, height, radius, 0, Math.PI * 2, true);
    jctx.fillStyle = '#F08080';
    jctx.fill();
    jctx.strokeStyle = '#F6ABAB';
    jctx.lineWidth = 8;
    jctx.stroke();
}

let coord = { x: 0, y: 0 };
let paint = false;

function getPosition(event) {
   e = window.event || e;
  var mouse_x = e.clientX || e.touches[0].clientX;
  var mouse_y = e.clientY || e.touches[0].clientY;
  coord.x = mouse_x - canvas.offsetLeft;
  coord.y = mouse_y - canvas.offsetTop;
}

function is_it_in_the_circle() {
    var current_radius = Math.sqrt(Math.pow(coord.x - x_orig, 2) + Math.pow(coord.y - y_orig, 2));
    if (radius >= current_radius) return true
    else return false
}


function startDrawing(event) {
    paint = true;
    getPosition(event);
    if (is_it_in_the_circle()) {
        jctx.clearRect(0, 0, canvas.width, canvas.height);
        background();
        joystick(coord.x, coord.y);
    }
    Draw();
}


function stopDrawing() {
    paint = false;
    jctx.clearRect(0, 0, canvas.width, canvas.height);
    background();
    joystick(width / 2, height / 3);
/*
    document.getElementById("x_coordinate").innerText = 0;
    document.getElementById("y_coordinate").innerText = 0;
    document.getElementById("speed").innerText = 0;
    document.getElementById("angle").innerText = 0;
    document.getElementById("dd").innerText = 0;
*/
}

function Draw(event) {

    if (paint) {
        jctx.clearRect(0, 0, canvas.width, canvas.height);
        background();
        var angle_in_degrees,x, y, speed;
        var angle = Math.atan2((coord.y - y_orig), (coord.x - x_orig));

        if (Math.sign(angle) == -1) {
            angle_in_degrees = Math.round(-angle * 180 / Math.PI);
        }
        else {
            angle_in_degrees =Math.round( 360 - angle * 180 / Math.PI);
        }


        if (is_it_in_the_circle()) {
            joystick(coord.x, coord.y);
            x = coord.x;
            y = coord.y;
        }
        else {
            x = radius * Math.cos(angle) + x_orig;
            y = radius * Math.sin(angle) + y_orig;
            joystick(x, y);
        }


        getPosition(event);

        var speed =  Math.round(100 * Math.sqrt(Math.pow(x - x_orig, 2) + Math.pow(y - y_orig, 2)) / radius);

        var x_relative = Math.round(x - x_orig);
        var y_relative = Math.round(y - y_orig);

        if (angle_in_degrees > 45 && angle_in_degrees <= 135) {
            if(aim!=up & aim!=0) {
                aim=up;
                socket.emit("up");
            }
        }
        else if (angle_in_degrees > 135 && angle_in_degrees <= 225) {
            if(aim!=left & aim!=0) {
                aim=left;
                socket.emit("left");
            }
        }
        else if (angle_in_degrees > 225 && angle_in_degrees <= 315) {
            if(aim!=down & aim!=0) {
                aim=down;
                socket.emit("down");
            }
        }
        else {
            if(aim!=right &aim!=0) {
                aim=right;
                socket.emit("right");
            }
        }
/*
        document.getElementById("x_coordinate").innerText =  x_relative;
        document.getElementById("y_coordinate").innerText =y_relative ;
        document.getElementById("speed").innerText = speed;
        document.getElementById("angle").innerText = angle_in_degrees;
        document.getElementById("dd").innerText = aim;
*/
    }
}

function arrowkeys(event) {
    if(event.keyCode == 37) {
        if(aim!=left) {
            aim=left;
            socket.emit("left");
        }
    } else  if(event.keyCode == 38) {
        if(aim!=up) {
            aim=up;
            socket.emit("up");
        }
    } else  if(event.keyCode == 39) {
        if(aim!=right) {
            aim=right;
            socket.emit("right");
        }
    } else  if(event.keyCode == 40) {
        if(aim!=down) {
            aim=down;
            socket.emit("down");
        }
    }
}
