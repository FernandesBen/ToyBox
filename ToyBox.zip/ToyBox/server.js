const express = require('express')
const http = require('http');
const path = require('path')
const socketio = require('socket.io');
const app = express()
var server = http.createServer(app)

app.use(express.static(__dirname + '/home'));

app.get('/', (req, res) => {
    res.sendFile('home/homepage.html', { //normally index.html
        root: path.join(__dirname, './')
    })
})

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
